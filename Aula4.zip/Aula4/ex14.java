import java.util.Scanner;

public class ex14 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        String b = a + "";
        String c = b.substring(0,2);
        if((a % 4) == 0){
           System.out.println("É multiplo de 4, o número formado é: " + c);
        }
        else{
            System.out.println("Não é multiplo de 4, o número formado é: " + c);
        }
        sc.close();
    }
}