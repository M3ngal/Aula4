import java.util.Scanner;

public class ex1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        System.out.println("Insira um número: ");
        int b = sc.nextInt();
        int c = a + b;
        if(c > 10){
            System.out.println("Resultado: " + c);
        }
        sc.close();
    }
}