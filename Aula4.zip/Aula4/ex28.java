import java.util.Scanner;

public class ex28 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira o nome: ");
        String a = sc.nextLine();
        a = a.toLowerCase();
        String b = a.substring(0,1);
        if("a".equals(b) || "b".equals(b) || "c".equals(b) || "d".equals(b) || "e".equals(b) || "f".equals(b) || "g".equals(b) || "h".equals(b) || "i".equals(b) || "j".equals(b) || "k".equals(b)) {
            System.out.println("D1");
        }
        else if("l".equals(b) || "m".equals(b) || "n".equals(b)) {
            System.out.println("D2");
        }
        else{
            System.out.println("D3");
        }
        sc.close();
    }
}