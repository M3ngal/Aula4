import java.util.Scanner;

public class ex27 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira o nome: ");
        String a = sc.nextLine();
        a = a.toLowerCase();
        String b = a.substring(a.length() - 2,a.length());
        if("r".equals(a.substring(a.length() - 1,a.length()))){
            System.out.println("Não está no infinitivo");
        }
        else if ("or".equals(b) || "ur".equals(b)){
            System.out.println("Provavelmente nem é verbo no infinitivo");
        }
        else if ("ar".equals(b)){
            System.out.println("1° Conjugação");
        }
        else if ("er".equals(b)){
            System.out.println("2° Conjugação");
        }
        else if ("ir".equals(b)){
            System.out.println("3° Conjugação");
        }
        sc.close();
    }
}