import java.util.Scanner;

public class ex7 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira o nome: ");
        String a = sc.nextLine();
        System.out.println("Insira o sexo: ");
        String b = sc.nextLine();
        System.out.println("Insira a idade: ");
        int c = sc.nextInt();
        b = b.toLowerCase();
        boolean d = "feminino".equals(b);
        if(d && c < 25){
            System.out.println(a + " Aceita");
        }
        else{
            System.out.println(a + " Não aceita");
        }
        sc.close();
    }
}