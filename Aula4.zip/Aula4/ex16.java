import java.util.Scanner;

public class ex16 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        System.out.println("Insira um número: ");
        int b = sc.nextInt();
        if(a == b){
            System.out.println("São iguais");
        }
        else{
            System.out.println("Não são iguais");
        }
        sc.close();
    }
}