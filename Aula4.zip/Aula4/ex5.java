import java.util.Scanner;

public class ex5 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        if(a > 20 && a < 90){
            System.out.println("Está compreendido");
        }
        else{
            System.out.println("Não está compreendido");
        }
        sc.close();
    }
}