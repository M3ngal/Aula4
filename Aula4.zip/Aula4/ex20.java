import java.util.Scanner;

public class ex20 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        System.out.println("Insira um número: ");
        int b = sc.nextInt();
        double min1 = Math.min(a,b);
        double max1 = Math.max(a,b);
        max1 = Math.sqrt(max1);
        min1 = Math.pow(min1,2);
        System.out.println("O quadrado do menor: " + min1 + " A raiz quadrada do maior: " + max1);
        sc.close();
    }
}