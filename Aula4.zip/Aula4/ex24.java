import java.util.Scanner;
import java.util.Arrays;

public class ex24 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira 5 números: ");
        int [] a  = {sc.nextInt(), 0, 0, 0, 0};
        a[1] = sc.nextInt();
        a[2] = sc.nextInt();
        a[3] = sc.nextInt();
        a[4] = sc.nextInt();
        Arrays.sort(a);
        System.out.println("Maior: " + a[4] + " Menor: " + a[0]);
        sc.close();
    }
}