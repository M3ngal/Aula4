import java.util.Scanner;

public class ex23 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int maior = 0;
        int intermediário = 0;
        int menor = 0;
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        System.out.println("Insira um número: ");
        int b = sc.nextInt();
        System.out.println("Insira um número: ");
        int c = sc.nextInt();
        int max1 = Math.max(a,b);
        int max2 = Math.max(a,c);
        int max3 = Math.max(b,c);
        int min1 = Math.min(a,b);
        int min2 = Math.min(a,c);
        int min3 = Math.min(b,c);
        if(max1 == max2){
            maior = max1;
        }
        else if(max1 == max3){
            maior = max1;
        }
        else if(max2 == max3){
            maior = max2;
        }
        if(min1 == min2){
            menor = min1;
            intermediário = min3;
        }
        else if(min1 == min3){
            menor = min1;
            intermediário = min2;
        }
        else if(min2 == min3){
            menor = min2;
            intermediário = min1;
        }
        System.out.println("Maior: " + maior + "Intermediário: " + intermediário + "Menor: " + menor);
        sc.close();
    }
}