import java.util.Scanner;

public class ex25 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        System.out.println("Insira um número: ");
        int b = sc.nextInt();
        System.out.println("Insira um número: ");
        int c = sc.nextInt();

        if((a + b) <= c){
            System.out.println("Não é um triângulo");
        }
        else if((a + c) <= b){
            System.out.println("Não é um triângulo");
        }
        else if((b + c) <= a){
            System.out.println("Não é um triângulo");
        }
        else{
            System.out.println("É um triângulo");
        }
        sc.close();
    }
}