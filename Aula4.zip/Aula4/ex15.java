import java.util.Scanner;

public class ex15 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira o ano de nascimento: ");
        int a = sc.nextInt();
        System.out.println("Insira ano atual: ");
        int b = sc.nextInt();
        if(b >= a){
            System.out.println("Idade: " + (b - a) + "anos");
        }
        else{
            System.out.println("Ano de nascimento inválido");
        }
        sc.close();
    }
}