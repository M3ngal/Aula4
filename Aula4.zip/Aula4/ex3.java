import java.util.Scanner;

public class ex3 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        double a = sc.nextDouble();
        if(a > 0){
            a = Math.sqrt(a);
            System.out.println("Resultado: " + a);
        }
        else{
            a = Math.pow(a,2);
            System.out.println("Resultado: " + a);  
        }
        sc.close();
    }
}