import java.util.Scanner;

public class ex18 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        System.out.println("Insira um número: ");
        int b = sc.nextInt();
        int min1 = Math.min(a,b);
        int max1 = Math.max(a,b);
        System.out.println(min1 + " -> " + max1);
        sc.close();
    }
}