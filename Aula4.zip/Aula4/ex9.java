import java.util.Scanner;

public class ex9 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        if((a % 3) == 0){
            System.out.println("É multiplo");
        }
        else{
            System.out.println("Não é multiplo");
        }
        sc.close();
    }
}