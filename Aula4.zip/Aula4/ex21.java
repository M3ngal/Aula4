import java.util.Scanner;

public class ex21 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        System.out.println("Insira um número: ");
        int b = sc.nextInt();
        System.out.println("Insira um número: ");
        int c = sc.nextInt();
        int max1 = Math.max(a,b);
        int max2 = Math.max(a,c);
        int max3 = Math.max(b,c);
        if(max1 == max2){
            System.out.println(max1);
        }
        else if(max1 == max3){
            System.out.println(max1);
        }
        else if(max2 == max3){
            System.out.println(max2);
        } 
        sc.close();
    }
}