import java.util.Scanner;

public class ex10 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        if((a % 5) == 0){
            System.out.println("É divisível");
        }
        else{
            System.out.println("Não é divisível");
        }
        sc.close();
    }
}