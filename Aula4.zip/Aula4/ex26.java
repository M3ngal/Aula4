import java.util.Scanner;

public class ex26 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean i = true;
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        while (i) {
            System.out.println("Insira um número: ");
            a = sc.nextInt();
            System.out.println("Insira um número: ");
            b = sc.nextInt();
            System.out.println("Insira um número: ");
            c = sc.nextInt();
            if ((a + b) <= c) {
                System.out.println("Não é um triângulo");
            }
            else if ((a + c) <= b) {
                System.out.println("Não é um triângulo");
            }
            else if ((b + c) <= a) {
                System.out.println("Não é um triângulo");
            }
            else {
                System.out.println("É um triângulo");
                i = false;
            }
        }
        if (a == b && a == c) {
            System.out.println("O triângulo é equilátero");
        }
        else if (a != b && a != c && b != c) {
            System.out.println("O triângulo é isóceles");
        }
        else {
            System.out.println("O triângulo é escaleno");
        }
        sc.close();
    }
}