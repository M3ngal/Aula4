import java.util.Scanner;

public class ex6 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        if(a > 20 ){
            System.out.println("Maior que 20");
        }
        else if(a == 20){
            System.out.println("Igual a 20");
        }
        else{
            System.out.println("Menor que 20");
        }
        sc.close();
    }
}