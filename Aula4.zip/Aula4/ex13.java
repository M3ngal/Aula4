import java.util.Scanner;

public class ex13 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Insira um número: ");
        int a = sc.nextInt();
        String b = a + "";
        String c = b.substring(2,3);
        System.out.println("Dezena: " + c);
        sc.close();
    }
}